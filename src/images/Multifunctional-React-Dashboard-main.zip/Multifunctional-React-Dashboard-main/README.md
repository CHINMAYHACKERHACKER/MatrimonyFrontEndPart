# MultifunctionalReactDashboard

## <a href="https://shoppymultidash.netlify.app/">VIEW LIVE RESULT</a>

![Image text](https://github.com/MorgDzh/MultifunctionalReactDashboard/blob/main/src/data/resimg.png)

## Intoduction

Responsive, beautiful admin panel with many widgets and functions such as: calendar, kanban, theming, tables, colorpicker, editor, charts and more.
